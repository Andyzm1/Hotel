public class Persona {
    protected String nYa;
    protected int id;
    public Persona (String Nya, int id){
        this.nYa = nYa;
        this.id=id;
    }

    public String getnYa() {
        return nYa;
    }

    public int getId() {
        return id;
    }

}
